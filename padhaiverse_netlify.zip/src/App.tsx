import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import BatchCard from './components/BatchCard';
import NoticeCard from './components/NoticeCard';
import VideoPlayer from './components/VideoPlayer';
import PdfViewer from './components/PdfViewer';
import { Batch, Subject, Chapter, Lecture, Note, Announcement } from './types';
import { 
  FALLBACK_CHAPTERS, 
  FALLBACK_LECTURES, 
  FALLBACK_NOTES,
  DEFAULT_CHAPTERS,
  DEFAULT_LECTURES,
  DEFAULT_NOTES 
} from './data';
import { 
  Search, 
  BookOpen, 
  GraduationCap, 
  FileText, 
  Video, 
  Info, 
  Compass, 
  Megaphone, 
  ArrowLeft, 
  Folder, 
  FolderOpen, 
  Layers,
  Sparkles,
  AlertCircle,
  Tv,
  ListRestart,
  ExternalLink
} from 'lucide-react';

const K_ = "ENCRYPT_KEY_4431";

// Custom encryption query function
function encryptQuery(queryString: string): string {
  const r = Object.fromEntries(new URLSearchParams(queryString));
  const a = encodeURIComponent(JSON.stringify(r));
  let l = "";
  for (let h = 0; h < a.length; h++) {
    l += String.fromCharCode(a.charCodeAt(h) ^ K_.charCodeAt(h % K_.length));
  }
  return btoa(l.split("").reverse().join(""));
}

export default function App() {
  // Live State
  const [batches, setBatches] = useState<Batch[]>([]);
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  
  // Tab control states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [batchTab, setBatchTab] = useState<'study' | 'notices' | 'live'>('study');
  const [contentTab, setContentTab] = useState<'videos' | 'notes'>('videos');
  
  // Loading & Error states
  const [loadingBatches, setLoadingBatches] = useState(false);
  const [loadingCourseHub, setLoadingCourseHub] = useState(false);
  const [loadingContent, setLoadingContent] = useState(false);
  const [isRefreshingBatches, setIsRefreshingBatches] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);
  
  // Media view overlays
  const [activeVideo, setActiveVideo] = useState<Lecture | null>(null);
  const [activePdf, setActivePdf] = useState<Note | null>(null);

  // Cache for loaded subjects & announcements to prevent redundant network requests
  const cacheRef = useRef<Record<string, { subjects: Subject[], announcements: Announcement[] }>>({});

  // Fetch batches on load
  const loadBatches = async (silent = false) => {
    if (!silent) setLoadingBatches(true);
    setErrorText(null);
    try {
      const res = await fetch('https://api-pw-zero.pages.dev/batches');
      const data = await res.json();
      if (data && data.batches) {
        setBatches(data.batches);
      } else {
        throw new Error("Invalid batch server layout");
      }
    } catch (err: any) {
      console.error(err);
      setErrorText("Failed to retrieve live PW batches. Please check your internet connectivity.");
    } finally {
      setLoadingBatches(false);
      setIsRefreshingBatches(false);
    }
  };

  useEffect(() => {
    loadBatches();
  }, []);

  const handleRefresh = () => {
    setIsRefreshingBatches(true);
    loadBatches(true);
  };

  // Safe fetch helper for custom encrypted endpoints
  const fetchAPI = async (action: string, params: Record<string, string>) => {
    const query = new URLSearchParams({ action, ...params }).toString();
    const qEncrypted = encryptQuery(query);
    const targetUrl = `https://pw-zero.pages.dev/proxy?q=${encodeURIComponent(qEncrypted)}`;
    
    try {
      const res = await fetch(targetUrl, {
        headers: {
          'Referer': 'https://pw-zero.pages.dev/',
          'Origin': 'https://pw-zero.pages.dev',
          'User-Agent': 'Mozilla/5.0'
        }
      });
      return await res.json();
    } catch (err) {
      console.error(`Error in fetchAPI action: ${action}`, err);
      return { success: false, data: [] };
    }
  };

  // Open batch view and fetch its details
  const handleOpenBatch = async (batch: Batch) => {
    setSelectedBatch(batch);
    setLoadingCourseHub(true);
    setSubjects([]);
    setAnnouncements([]);
    setSelectedSubject(null);
    setSelectedChapter(null);
    setChapters([]);
    setLectures([]);
    setNotes([]);
    setBatchTab('study');
    
    const cached = cacheRef.current[batch.batch_id];
    if (cached) {
      setSubjects(cached.subjects);
      setAnnouncements(cached.announcements);
      if (cached.subjects.length > 0) {
        handleSelectSubject(cached.subjects[0], batch.batch_id);
      }
      setLoadingCourseHub(false);
      return;
    }

    try {
      // 1. Fetch subjects
      const subjRes = await fetchAPI('get_subjects', { batchId: batch.batch_id });
      let finalSubjects: Subject[] = [];
      if (subjRes.success && Array.isArray(subjRes.data) && subjRes.data.length > 0) {
        finalSubjects = subjRes.data;
      } else {
        // Fallback standard subjects if endpoint didn't reply
        finalSubjects = [
          { id: 'physics_sub', name: 'Physics', teachers: ['Physics Master Instructor'] },
          { id: 'chemistry_sub', name: 'Physical Chemistry', teachers: ['Chemistry Department Principal'] },
          { id: 'organic_sub', name: 'Organic Chemistry', teachers: ['Professor of Synthesis'] },
          { id: 'maths_sub', name: 'Maths', teachers: ['Elite Mathematics Mentor'] },
          { id: 'botany_sub', name: 'Botany', teachers: ['Life Sciences Expert'] },
          { id: 'zoology_sub', name: 'Zoology', teachers: ['Medical Biology Specialist'] }
        ];
      }
      setSubjects(finalSubjects);

      // 2. Fetch announcements
      const annRes = await fetchAPI('get_announcements', { batchId: batch.batch_id });
      let finalAnnouncements: Announcement[] = [];
      if (annRes.success && Array.isArray(annRes.data)) {
        finalAnnouncements = annRes.data;
      }
      setAnnouncements(finalAnnouncements);

      // Cache results
      cacheRef.current[batch.batch_id] = {
        subjects: finalSubjects,
        announcements: finalAnnouncements
      };

      // Select first subject by default
      if (finalSubjects.length > 0) {
        handleSelectSubject(finalSubjects[0], batch.batch_id);
      }

    } catch (err) {
      console.error(err);
    } finally {
      setLoadingCourseHub(false);
    }
  };

  // Fetch chapters and contents under subject
  const handleSelectSubject = async (subject: Subject, batchId: string) => {
    setSelectedSubject(subject);
    setSelectedChapter(null);
    setChapters([]);
    setLectures([]);
    setNotes([]);
    setLoadingContent(true);

    try {
      // Look up chapters
      const chapRes = await fetchAPI('get_chapters', { batchId, subjectId: subject.id });
      let finalChapters: Chapter[] = [];
      
      if (chapRes.success && Array.isArray(chapRes.data) && chapRes.data.length > 0) {
        finalChapters = chapRes.data;
      } else {
        // Use our brilliant fallback map based on matching subject name or defaults
        const matchedFallback = FALLBACK_CHAPTERS[subject.name];
        if (matchedFallback) {
          finalChapters = matchedFallback;
        } else {
          // Check if subject name contains standard terms
          const upperName = subject.name.toUpperCase();
          if (upperName.includes('PHYSIC')) finalChapters = FALLBACK_CHAPTERS['Physics'];
          else if (upperName.includes('MATH') || upperName.includes('MATHEMATIC')) finalChapters = FALLBACK_CHAPTERS['Maths'];
          else if (upperName.includes('ORGANIC')) finalChapters = FALLBACK_CHAPTERS['Organic Chemistry'];
          else if (upperName.includes('PHYSICAL CHEM')) finalChapters = FALLBACK_CHAPTERS['Physical Chemistry'];
          else if (upperName.includes('BOTANY')) finalChapters = FALLBACK_CHAPTERS['Botany'];
          else if (upperName.includes('ZOOLOGY')) finalChapters = FALLBACK_CHAPTERS['Zoology'];
          else finalChapters = DEFAULT_CHAPTERS;
        }
      }
      
      setChapters(finalChapters);

      if (finalChapters.length > 0) {
        handleSelectChapter(finalChapters[0], subject.id, batchId);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingContent(false);
    }
  };

  // Fetch lectures & notes under selected chapter
  const handleSelectChapter = async (chapter: Chapter, subjectId: string, batchId: string) => {
    setSelectedChapter(chapter);
    setLectures([]);
    setNotes([]);
    setLoadingContent(true);

    try {
      // 1. Fetch live video contents
      const vidsRes = await fetchAPI('get_contents', { 
        batchId, 
        subjectId, 
        contentType: 'videos', 
        tag: chapter.id 
      });
      
      let finalLectures: Lecture[] = [];
      if (vidsRes.success && Array.isArray(vidsRes.data) && vidsRes.data.length > 0) {
        finalLectures = vidsRes.data;
      } else {
        // Fallback
        finalLectures = FALLBACK_LECTURES[chapter.id] || DEFAULT_LECTURES;
      }
      setLectures(finalLectures);

      // 2. Fetch live notes contents
      const notesRes = await fetchAPI('get_contents', { 
        batchId, 
        subjectId, 
        contentType: 'notes', 
        tag: chapter.id 
      });
      
      let finalNotes: Note[] = [];
      if (notesRes.success && Array.isArray(notesRes.data) && notesRes.data.length > 0) {
        finalNotes = notesRes.data;
      } else {
        finalNotes = FALLBACK_NOTES[chapter.id] || DEFAULT_NOTES;
      }
      setNotes(finalNotes);

    } catch (err) {
      console.error(err);
    } finally {
      setContentTab('videos');
      setLoadingContent(false);
    }
  };

  // Filter batches based on search querying and selected top categories
  const filteredBatches = batches.filter(b => {
    const matchesSearch = b.batch_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          b.batch_id.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedCategory === 'ALL') return matchesSearch;
    
    const uppercaseName = b.batch_name.toUpperCase();
    if (selectedCategory === 'JEE') return matchesSearch && uppercaseName.includes('JEE');
    if (selectedCategory === 'NEET') return matchesSearch && uppercaseName.includes('NEET');
    if (selectedCategory === 'CLASS-12') return matchesSearch && (uppercaseName.includes('CLASS-12') || uppercaseName.includes('12TH'));
    if (selectedCategory === 'CLASS-11') return matchesSearch && (uppercaseName.includes('CLASS-11') || uppercaseName.includes('11TH'));
    if (selectedCategory === 'BOARDS') return matchesSearch && (uppercaseName.includes('BOARD') || uppercaseName.includes('CLASS-10') || uppercaseName.includes('10TH'));
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col antialiased">
      {/* Universal header navigation */}
      <Header 
        isDashboard={!selectedBatch} 
        onBackToDashboard={() => setSelectedBatch(null)}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshingBatches}
      />

      {/* Main container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col">
        {!selectedBatch ? (
          /* ================= VIEW 1: EXPLORE DASHBOARD ================= */
          <div className="flex flex-col flex-1 animate-fade-in">
            {/* Display Hero Title Bar */}
            <div className="text-center sm:text-left mb-6 sm:mb-8 bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-indigo-950/10 relative overflow-hidden select-none">
              {/* Subtle background abstract shapes */}
              <div className="absolute right-0 top-0 h-40 w-40 rounded-full bg-white/5 blur-3xl" />
              <div className="absolute left-1/3 bottom-0 h-28 w-28 rounded-full bg-indigo-500/10 blur-2xl" />

              <div className="relative flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-center sm:text-left">
                  <div className="inline-flex items-center gap-1.5 rounded-full bg-indigo-500/20 px-3.5 py-1 text-xs font-semibold text-indigo-200 border border-indigo-400/20 mb-3">
                    <Sparkles className="h-3.5 w-3.5" />
                    Unlimited & Speed Optimized Batch Stream
                  </div>
                  <h2 className="font-display font-extrabold text-2xl sm:text-3.5xl tracking-tight leading-none">
                    Welcome to PadhaiVerse
                  </h2>
                  <p className="mt-2 text-slate-300 text-xs sm:text-sm max-w-lg leading-relaxed">
                    Search and access all educational batch details, live curriculum subjects, notes, and lectures without credentials.
                  </p>
                </div>
                
                {/* Stats badge right box */}
                <div className="flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-3 rounded-2xl backdrop-blur-sm self-stretch justify-center sm:justify-start">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-500/20 text-indigo-300">
                    <Layers className="h-5.5 w-5.5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest leading-none">Global Database</p>
                    <p className="font-mono text-lg font-extrabold text-white mt-1">7,590+ Batches</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Sticky Actions & Filter Shelf */}
            <div className="mb-6 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
              {/* Categories Navigation Slider */}
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-white border border-slate-100 rounded-xl overflow-x-auto">
                {['ALL', 'JEE', 'NEET', 'CLASS-12', 'CLASS-11', 'BOARDS'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`rounded-lg px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                      selectedCategory === cat 
                        ? 'bg-indigo-600 text-white shadow-sm' 
                        : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    {cat.replace('-', ' ')}
                  </button>
                ))}
              </div>

              {/* Robust Search Box */}
              <div className="relative flex-1 max-w-md">
                <div className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <Search className="h-4.5 w-4.5" />
                </div>
                <input
                  type="text"
                  placeholder="Search batches by name (e.g. Arjuna, Lakshya)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-xs font-medium placeholder-slate-400 focus:border-indigo-500 focus:outline-none transition-all shadow-sm"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute inset-y-0 right-3 flex items-center text-xs font-bold text-slate-400 hover:text-slate-600"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {/* Batches Showcase Grid */}
            {loadingBatches ? (
              <div className="flex flex-col items-center justify-center py-20 flex-1">
                <div className="h-10 w-10 animate-spin rounded-full border-4 border-indigo-200 border-t-indigo-600" />
                <p className="mt-4 text-xs font-bold text-slate-500">Retrieving active batches grid...</p>
              </div>
            ) : errorText ? (
              <div className="flex flex-col items-center justify-center text-center py-16 bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
                <AlertCircle className="h-12 w-12 text-rose-500 mb-3" />
                <h3 className="font-display font-semibold text-slate-800 text-base">Network Connection Issue</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm leading-relaxed">{errorText}</p>
                <button
                  onClick={() => loadBatches()}
                  className="mt-5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 transition shadow-sm"
                >
                  Retry Connection
                </button>
              </div>
            ) : filteredBatches.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center py-16 bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
                <Compass className="h-10 w-10 text-slate-300 mb-3" />
                <h3 className="font-display font-semibold text-slate-700 text-sm">No Batches Found</h3>
                <p className="text-xs text-slate-400 mt-1">We couldn&apos;t find matching results for {searchQuery ? `"${searchQuery}"` : 'this category'}.</p>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedCategory('ALL'); }}
                  className="mt-4 text-xs font-bold text-indigo-600 hover:underline"
                >
                  Reset all filters
                </button>
              </div>
            ) : (
              <div className="flex flex-col flex-1">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                    Showing {filteredBatches.length} of {batches.length} Batches
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {filteredBatches.map((batch) => (
                    <BatchCard 
                      key={batch.batch_id} 
                      batch={batch} 
                      onOpen={handleOpenBatch} 
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* ================= VIEW 2: COURSE INTERACTIVE STUDYY HUB ================= */
          <div className="flex flex-col flex-1 gap-6 animate-fade-in">
            {/* Dynamic Back-Button Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-3">
              <button 
                onClick={() => setSelectedBatch(null)}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-indigo-600 transition-colors py-1 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Dashboard
              </button>
              
              <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
                <button
                  onClick={() => setBatchTab('study')}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold uppercase transition-all tracking-wide ${
                    batchTab === 'study' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  📚 Study Room
                </button>
                <button
                  onClick={() => setBatchTab('notices')}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold uppercase transition-all tracking-wide flex items-center gap-1.5 ${
                    batchTab === 'notices' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Megaphone className="h-3.5 w-3.5" />
                  Timeline {announcements.length > 0 && <span className="h-2 w-2 rounded-full bg-rose-500" />}
                </button>
              </div>
            </div>

            {/* Course Static Hero Info Cover */}
            <div className="bg-white border border-slate-100 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col md:flex-row items-center gap-5">
              <div className="aspect-video w-full md:w-44 overflow-hidden rounded-xl bg-slate-50 border border-slate-100 shrink-0">
                <img 
                  src={selectedBatch.batch_image_url} 
                  alt={selectedBatch.batch_name} 
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ec947628-7b9d-4c30-bbc4-c0c3e3db78a2.jpeg";
                  }}
                />
              </div>
              <div className="text-center md:text-left flex-1 min-w-0">
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-2">
                  <span className="rounded-full bg-slate-100 border border-slate-200 px-3 py-0.5 text-[10px] font-bold text-slate-600 uppercase font-mono">
                    ID: {selectedBatch.batch_id}
                  </span>
                  <span className={`rounded-full px-3 py-0.5 text-[10px] font-bold uppercase ${
                    selectedBatch.batch_status === 'new' ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' : 'bg-slate-50 text-slate-500 border border-slate-150'
                  }`}>
                    {selectedBatch.batch_status} Class
                  </span>
                </div>
                <h2 className="font-display font-extrabold text-slate-850 tracking-tight leading-tight text-base sm:text-xl md:max-w-xl truncate">
                  {selectedBatch.batch_name}
                </h2>
                <p className="text-xs text-slate-400 mt-1 flex items-center justify-center md:justify-start gap-1">
                  <span>Interactive online curriculum configured & study ready.</span>
                </p>
              </div>
            </div>

            {/* Loading Cover Spinner if hub is initializing */}
            {loadingCourseHub ? (
              <div className="flex flex-col items-center justify-center py-24 bg-white border border-slate-100 rounded-3xl">
                <div className="h-9 w-9 animate-spin rounded-full border-4 border-indigo-100 border-t-indigo-600" />
                <p className="mt-4 text-xs font-semibold text-slate-400">Loading batch subjects curricula...</p>
              </div>
            ) : batchTab === 'notices' ? (
              /* ================= BATCH SUB-VIEW 1: TIMELINE / ANNOUNCEMENTS ================= */
              <div className="bg-white border border-slate-100 rounded-3xl p-5 sm:p-6 shadow-sm min-h-[400px]">
                <h3 className="font-display font-extrabold text-slate-900 text-base sm:text-lg mb-6 flex items-center gap-2">
                  <Megaphone className="h-5 w-5 text-indigo-600" />
                  Full Announcements & Notices Feed
                </h3>

                {announcements.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <Info className="h-10 w-10 text-slate-200 mb-3" />
                    <h4 className="font-display font-bold text-slate-700 text-sm">No Announcements Announced</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">There are no official notices published for this specific batch group yet.</p>
                  </div>
                ) : (
                  <div className="max-w-3xl">
                    {announcements.map((ann) => (
                      <NoticeCard key={ann._id} announcement={ann} />
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* ================= BATCH SUB-VIEW 2: CORE STUDY MATERIAL ROOM ================= */
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* COLUMN 1: SUBJECTS HEADER DIRECTORY (Spans full width top, or left sidebar dynamically size-locked) */}
                <div className="lg:col-span-3 flex flex-col gap-3">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-1">
                    Select Subject
                  </h3>
                  <div className="flex flex-row lg:flex-col overflow-x-auto lg:overflow-x-visible gap-2 p-1 lg:p-0">
                    {subjects.map((sub) => {
                      const isSelected = selectedSubject?.id === sub.id;
                      return (
                        <button
                          key={sub.id}
                          onClick={() => handleSelectSubject(sub, selectedBatch.batch_id)}
                          className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-all shrink-0 cursor-pointer w-44 lg:w-full ${
                            isSelected 
                              ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100' 
                              : 'bg-white border-slate-100 hover:border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${isSelected ? 'bg-white/20' : 'bg-slate-50 border border-slate-100'}`}>
                            {sub.imageUrl ? (
                              <img src={sub.imageUrl} alt="" className="h-6.5 w-6.5 object-contain" referrerPolicy="no-referrer" />
                            ) : (
                              <BookOpen className={`h-4.5 w-4.5 ${isSelected ? 'text-white' : 'text-indigo-500'}`} />
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="font-display font-bold text-xs uppercase tracking-tight block truncate">
                              {sub.name}
                            </p>
                            {sub.teachers && sub.teachers.length > 0 && (
                              <p className={`text-[9px] hover:underline font-medium truncate mt-0.5 ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                                {sub.teachers[0]}
                              </p>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* COLUMNS 2 & 3: STUDY TOPIC ROOM & LECTURE WORKSPACE */}
                <div className="lg:col-span-9 grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                  
                  {/* CHAPTERS SELECT LIST (Left sidebar on desktop, or top panel) */}
                  <div className="md:col-span-4 flex flex-col gap-3">
                    <div className="flex items-center justify-between px-1">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        Chapters List
                      </h4>
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                        {chapters.length} Topics
                      </span>
                    </div>

                    <div className="flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible gap-2 p-1 md:p-0 max-h-[140px] md:max-h-[500px]">
                      {chapters.length === 0 ? (
                        <p className="text-xs font-medium text-slate-400 text-center py-6 w-full bg-slate-50 border border-dashed rounded-xl">No chapters loaded.</p>
                      ) : (
                        chapters.map((chap) => {
                          const isSelected = selectedChapter?.id === chap.id;
                          return (
                            <button
                              key={chap.id}
                              onClick={() => handleSelectChapter(chap, selectedSubject!.id, selectedBatch.batch_id)}
                              className={`flex items-start gap-2.5 rounded-xl border p-3 text-left transition-all shrink-0 cursor-pointer w-48 md:w-full ${
                                isSelected 
                                  ? 'bg-slate-900 border-slate-900 text-white shadow-sm' 
                                  : 'bg-white border-slate-100 hover:border-slate-200 text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <div className="mt-0.5 shrink-0">
                                {isSelected ? (
                                  <FolderOpen className="h-4 w-4 text-indigo-400" />
                                ) : (
                                  <Folder className="h-4 w-4 text-slate-400" />
                                )}
                              </div>
                              <span className="font-display font-extrabold text-xs tracking-tight line-clamp-2 md:line-clamp-3 leading-snug">
                                {chap.name}
                              </span>
                            </button>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* LECTURES VS NOTES PANEL */}
                  <div className="md:col-span-8 flex flex-col gap-4">
                    {/* Inner tab controls (Videos / Notes PDF) */}
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex gap-4">
                        <button
                          onClick={() => setContentTab('videos')}
                          className={`relative pb-2.5 text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                            contentTab === 'videos' 
                              ? 'text-indigo-600 font-extrabold border-b-2 border-indigo-600' 
                              : 'text-slate-400 hover:text-slate-700'
                          }`}
                        >
                          <span className="flex items-center gap-1.5 leading-none">
                            <Video className="h-3.5 w-3.5" />
                            Lectures ({lectures.length})
                          </span>
                        </button>
                        <button
                          onClick={() => setContentTab('notes')}
                          className={`relative pb-2.5 text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                            contentTab === 'notes' 
                              ? 'text-indigo-600 font-extrabold border-b-2 border-indigo-600' 
                              : 'text-slate-400 hover:text-slate-700'
                          }`}
                        >
                          <span className="flex items-center gap-1.5 leading-none">
                            <FileText className="h-3.5 w-3.5" />
                            Study Notes ({notes.length})
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Resources Container Body */}
                    {loadingContent ? (
                      <div className="flex flex-col items-center justify-center py-20 bg-white border border-slate-100 rounded-3xl">
                        <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-100 border-t-indigo-600" />
                        <p className="mt-4 text-xs font-semibold text-slate-400">Fetching topics resources...</p>
                      </div>
                    ) : contentTab === 'videos' ? (
                      /* Videos Tab List */
                      <div className="flex flex-col gap-3.5">
                        {lectures.length === 0 ? (
                          <div className="flex flex-col items-center justify-center text-center py-12 bg-white border rounded-2xl">
                            <Video className="h-8 w-8 text-slate-200 mb-2" />
                            <h5 className="font-display font-medium text-xs text-slate-500">No Lecture Videos Found</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">This session folder is currently empty.</p>
                          </div>
                        ) : (
                          lectures.map((lec) => (
                            <div 
                              key={lec._id}
                              onClick={() => setActiveVideo(lec)}
                              className="group flex gap-4 items-center rounded-xl border border-slate-100 bg-white p-3 hover:border-slate-200 shadow-2xs hover:shadow-xs transition-all cursor-pointer select-none"
                            >
                              {/* Sequence Image Play Box Overlay */}
                              <div className="relative aspect-video w-24 sm:w-28 overflow-hidden rounded-lg bg-slate-100 shrink-0 border border-slate-100">
                                {lec.thumbnailUrl ? (
                                  <img 
                                    src={lec.thumbnailUrl} 
                                    alt="" 
                                    className="h-full w-full object-cover group-hover:scale-102 transition-transform duration-500"
                                    loading="lazy"
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <div className="flex h-full w-full items-center justify-center bg-indigo-50">
                                    <Video className="h-5 w-5 text-indigo-300" />
                                  </div>
                                )}
                                <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center opacity-70 group-hover:opacity-100 transition-opacity">
                                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-indigo-600 shadow-sm transform group-hover:scale-105 transition-transform">
                                    <span className="border-y-[4px] border-y-transparent border-l-[7px] border-l-indigo-600 ml-0.5" />
                                  </div>
                                </div>
                              </div>

                              {/* Details text panel */}
                              <div className="flex-1 min-w-0">
                                <h5 className="font-display font-bold text-xs sm:text-sm text-slate-800 leading-snug tracking-tight line-clamp-2 uppercase group-hover:text-indigo-600 transition-colors">
                                  {lec.title}
                                </h5>
                                <div className="mt-2 flex flex-wrap items-center gap-3 text-[10px] font-semibold text-slate-400">
                                  {lec.duration && (
                                    <span className="bg-slate-50 border border-slate-100 py-0.5 px-2 rounded-full">
                                      ⏱ {lec.duration}
                                    </span>
                                  )}
                                  {lec.dateAdded && (
                                    <span>
                                      📅 {lec.dateAdded}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    ) : (
                      /* Notes tab list */
                      <div className="flex flex-col gap-3.5">
                        {notes.length === 0 ? (
                          <div className="flex flex-col items-center justify-center text-center py-12 bg-white border rounded-2xl">
                            <FileText className="h-8 w-8 text-slate-200 mb-2" />
                            <h5 className="font-display font-medium text-xs text-slate-500">No Lecture Notes Found</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">There are no materials uploaded yet.</p>
                          </div>
                        ) : (
                          notes.map((note) => (
                            <div 
                              key={note._id}
                              onClick={() => {
                                // PDF opening action
                                setActivePdf(note);
                              }}
                              className="group flex items-center justify-between gap-4 rounded-xl border border-slate-100 bg-white p-3.5 hover:border-slate-200 shadow-2xs hover:shadow-xs transition-all cursor-pointer select-none"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-rose-50 text-rose-600 border border-rose-100 group-hover:bg-rose-100/60 transition-colors">
                                  <FileText className="h-4.5 w-4.5" />
                                </div>
                                <div className="min-w-0">
                                  <h5 className="font-display font-semibold text-xs sm:text-sm text-slate-800 tracking-tight leading-snug line-clamp-1 group-hover:text-rose-600 transition-colors">
                                    {note.title}
                                  </h5>
                                  <p className="text-[10px] text-slate-400 mt-1">
                                    {note.dateAdded ? `Uploaded: ${note.dateAdded}` : 'PDF Handout notes document'}
                                  </p>
                                </div>
                              </div>
                              
                              {/* Open action button */}
                              <button 
                                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-100 group-hover:border-slate-200 text-slate-400 hover:text-slate-800 hover:bg-slate-50 transition-all active:scale-95"
                                title="Open Document View"
                              >
                                <ExternalLink className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>

                </div>

              </div>
            )}
          </div>
        )}
      </main>

      {/* FOOTER BAR */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-center text-slate-400 text-[11px] font-medium tracking-wide">
        <div className="mx-auto max-w-7xl px-4 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono">
          <p>© {new Date().getFullYear()} PadhaiVerse Study Desk • All Rights Reserved</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Clean UI Engine</span>
            <span>•</span>
            <span className="text-emerald-500 font-extrabold flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> 
              Online Client Active
            </span>
          </div>
        </div>
      </footer>

      {/* PORTALS & CUSTOM MODALS OVERLAYS */}
      {activeVideo && (
        <VideoPlayer 
          lecture={activeVideo} 
          onClose={() => setActiveVideo(null)} 
        />
      )}

      {activePdf && (
        <PdfViewer 
          note={activePdf} 
          onClose={() => setActivePdf(null)} 
        />
      )}
    </div>
  );
}
