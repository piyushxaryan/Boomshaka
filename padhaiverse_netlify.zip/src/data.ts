import { Chapter, Lecture, Note } from './types';

export const FALLBACK_CHAPTERS: Record<string, Chapter[]> = {
  // Physics subject
  'Physics': [
    { id: 'phy_ch1', name: 'Units & Dimensions' },
    { id: 'phy_ch2', name: 'Vectors & Basic Mathematics' },
    { id: 'phy_ch3', name: 'Kinematics in 1D & 2D' },
    { id: 'phy_ch4', name: 'Laws of Motion (NLM)' },
    { id: 'phy_ch5', name: 'Work, Power & Energy' },
    { id: 'phy_ch6', name: 'Electrostatics & Potential' },
    { id: 'phy_ch7', name: 'Current Electricity' },
    { id: 'phy_ch8', name: 'Magnetism & Matter' }
  ],
  'Maths': [
    { id: 'math_ch1', name: 'Sets, Relations & Functions' },
    { id: 'math_ch2', name: 'Quadratic Equations' },
    { id: 'math_ch3', name: 'Complex Numbers' },
    { id: 'math_ch4', name: 'Matrices & Determinants' },
    { id: 'math_ch5', name: 'Limits, Continuity & Differentiability' },
    { id: 'math_ch6', name: 'Differentiation & Derivatives' },
    { id: 'math_ch7', name: 'Integration & Areas' }
  ],
  'Physical Chemistry': [
    { id: 'pc_ch1', name: 'Some Basic Concepts of Chemistry (Mole Concept)' },
    { id: 'pc_ch2', name: 'Structure of Atom' },
    { id: 'pc_ch3', name: 'Chemical Bonding' },
    { id: 'pc_ch4', name: 'Thermodynamics & Thermochemistry' },
    { id: 'pc_ch5', name: 'Chemical & Ionic Equilibrium' },
    { id: 'pc_ch6', name: 'Solutions & Colligative Properties' }
  ],
  'Organic Chemistry': [
    { id: 'oc_ch1', name: 'General Organic Chemistry (GOC) - Part 1' },
    { id: 'oc_ch2', name: 'General Organic Chemistry (GOC) - Part 2' },
    { id: 'oc_ch3', name: 'Hydrocarbons (Alkanes, Alkenes, Alkynes)' },
    { id: 'oc_ch4', name: 'Haloalkanes & Haloarenes' },
    { id: 'oc_ch5', name: 'Alcohols, Phenols & Ethers' }
  ],
  'Botany': [
    { id: 'bot_ch1', name: 'The Living World' },
    { id: 'bot_ch2', name: 'Biological Classification' },
    { id: 'bot_ch3', name: 'Plant Kingdom' },
    { id: 'bot_ch4', name: 'Cell: The Unit of Life' },
    { id: 'bot_ch5', name: 'Photosynthesis in Higher Plants' }
  ],
  'Zoology': [
    { id: 'zoo_ch1', name: 'Animal Kingdom' },
    { id: 'zoo_ch2', name: 'Structural Organisation in Animals' },
    { id: 'zoo_ch3', name: 'Biomolecules' },
    { id: 'zoo_ch4', name: 'Human Digestion & Absorption' },
    { id: 'zoo_ch5', name: 'Breathing & Exchange of Gases' }
  ]
};

export const FALLBACK_LECTURES: Record<string, Lecture[]> = {
  'phy_ch1': [
    { _id: 'phy_l1_1', title: 'L-01: Introduction to Physical Quantities & Dimensions', duration: '1h 15m', youtubeId: 'tK3MTo7f_H4', dateAdded: 'May 20, 2026', thumbnailUrl: 'https://img.youtube.com/vi/tK3MTo7f_H4/0.jpg' },
    { _id: 'phy_l1_2', title: 'L-02: Dimensional analysis and its Applications', duration: '1h 30m', youtubeId: '2UjZ1IovB1A', dateAdded: 'May 22, 2026', thumbnailUrl: 'https://img.youtube.com/vi/2UjZ1IovB1A/0.jpg' },
    { _id: 'phy_l1_3', title: 'L-03: Measurement of Errors and Significant Figures', duration: '1h 45m', youtubeId: 'X07F7i6O97w', dateAdded: 'May 25, 2026', thumbnailUrl: 'https://img.youtube.com/vi/X07F7i6O97w/0.jpg' }
  ],
  'phy_ch2': [
    { _id: 'phy_l2_1', title: 'L-01: Vectors Representation, Addition & Subtraction', duration: '1h 22m', youtubeId: 'E6FOnSAtzic', dateAdded: 'May 24, 2026', thumbnailUrl: 'https://img.youtube.com/vi/E6FOnSAtzic/0.jpg' },
    { _id: 'phy_l2_2', title: 'L-02: Dot Product, Cross Product & Component Resolution', duration: '1h 40m', youtubeId: '9vXG7-2k5tI', dateAdded: 'May 26, 2026', thumbnailUrl: 'https://img.youtube.com/vi/9vXG7-2k5tI/0.jpg' }
  ],
  'phy_ch3': [
    { _id: 'phy_l3_1', title: 'L-01: Motion in a Straight Line, Velocity & Acceleration', duration: '1h 15m', youtubeId: '4-X_8uGbyas', dateAdded: 'May 25, 2026', thumbnailUrl: 'https://img.youtube.com/vi/4-X_8uGbyas/0.jpg' },
    { _id: 'phy_l3_2', title: 'L-02: Kinematics Equations & Motion Under Gravity', duration: '1h 35m', youtubeId: 'A8uPz7a_YxU', dateAdded: 'May 27, 2026', thumbnailUrl: 'https://img.youtube.com/vi/A8uPz7a_YxU/0.jpg' }
  ],
  'math_ch1': [
    { _id: 'math_l1_1', title: 'L-01: Basics of Sets, Types of Sets and Venn Diagrams', duration: '1h 10m', youtubeId: '3K-jsh-WjK0', dateAdded: 'May 18, 2026', thumbnailUrl: 'https://img.youtube.com/vi/3K-jsh-WjK0/0.jpg' },
    { _id: 'math_l1_2', title: 'L-02: Relations, Cartesians Product and Domain & Range', duration: '1h 25m', youtubeId: 'm4XgY1239Xw', dateAdded: 'May 21, 2026', thumbnailUrl: 'https://img.youtube.com/vi/m4XgY1239Xw/0.jpg' }
  ],
  'math_ch4': [
    { _id: 'math_l4_1', title: 'L-01: Introduction to Matrices, Types and Operations', duration: '1h 28m', youtubeId: '9g9I6vveS5M', dateAdded: 'May 22, 2026', thumbnailUrl: 'https://img.youtube.com/vi/9g9I6vveS5M/0.jpg' },
    { _id: 'math_l4_2', title: 'L-02: Multiplication of Matrices and Transpose Properties', duration: '1h 40m', youtubeId: 'e4u63W87XUw', dateAdded: 'May 24, 2026', thumbnailUrl: 'https://img.youtube.com/vi/e4u63W87XUw/0.jpg' }
  ],
  'pc_ch1': [
    { _id: 'pc_l1_1', title: 'L-01: Laws of Chemical Combination & Introduction to Mole', duration: '1h 30m', youtubeId: 'j80gP9eK45I', dateAdded: 'May 15, 2026', thumbnailUrl: 'https://img.youtube.com/vi/j80gP9eK45I/0.jpg' },
    { _id: 'pc_l1_2', title: 'L-02: Empirical Formula, Molecular Formula & Stoichiometry', duration: '1h 45m', youtubeId: '57mXp9k7_U8', dateAdded: 'May 17, 2026', thumbnailUrl: 'https://img.youtube.com/vi/57mXp9k7_U8/0.jpg' }
  ],
  'oc_ch1': [
    { _id: 'oc_l1_1', title: 'L-01: IUPAC Nomenclature of Organic Compounds - Part I', duration: '1h 20m', youtubeId: 'u7r6X_Y6u9E', dateAdded: 'May 16, 2026', thumbnailUrl: 'https://img.youtube.com/vi/u7r6X_Y6u9E/0.jpg' },
    { _id: 'oc_l1_2', title: 'L-02: Inductive Effect, Resonance & Electromeric Actions', duration: '1h 48m', youtubeId: '9n9v_N79T_w', dateAdded: 'May 19, 2026', thumbnailUrl: 'https://img.youtube.com/vi/9n9v_N79T_w/0.jpg' }
  ],
  'bot_ch4': [
    { _id: 'bot_l4_1', title: 'L-01: Cell Theory, Prokaryotic and Eukaryotic Cells', duration: '1h 12m', youtubeId: '9_X9N49vT_I', dateAdded: 'May 15, 2026', thumbnailUrl: 'https://img.youtube.com/vi/9_X9N49vT_I/0.jpg' },
    { _id: 'bot_l4_2', title: 'L-02: Detailed Structure of Cell Membrane and Plastids', duration: '1h 30m', youtubeId: 'X07K4k7N_Ew', dateAdded: 'May 18, 2026', thumbnailUrl: 'https://img.youtube.com/vi/X07K4k7N_Ew/0.jpg' }
  ]
};

export const FALLBACK_NOTES: Record<string, Note[]> = {
  'phy_ch1': [
    { _id: 'phy_n1_1', title: 'Class Lecture Notes - Units, dimensions & dimensional formulas', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', dateAdded: 'May 20, 2026' },
    { _id: 'phy_n1_2', title: 'NCERT Exemplar Problems with Solutions - Chapter 1 & 2', fileUrl: 'https://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf', dateAdded: 'May 22, 2026' },
    { _id: 'phy_n1_3', title: 'Formulas Cheat Sheet & Dimensional Equations list', fileUrl: 'https://www.orimi.com/pdf-test.pdf', dateAdded: 'May 25, 2026' }
  ],
  'phy_ch2': [
    { _id: 'phy_n2_1', title: 'Class Lecture Notes - Vector Analysis & Calculations', fileUrl: 'https://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf', dateAdded: 'May 24, 2026' }
  ],
  'phy_ch3': [
    { _id: 'phy_n3_1', title: 'Class Lecture Notes - Kinematics Formulas & Derivations', fileUrl: 'https://www.orimi.com/pdf-test.pdf', dateAdded: 'May 25, 2026' }
  ],
  'math_ch1': [
    { _id: 'math_n1_1', title: 'Detailed Sets, Venn Diagrams & Relations Notes', fileUrl: 'https://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf', dateAdded: 'May 18, 2026' }
  ],
  'oc_ch1': [
    { _id: 'oc_n1_1', title: 'IUPAC Naming Conventions & Organic Acids list', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', dateAdded: 'May 16, 2026' }
  ],
  'bot_ch4': [
    { _id: 'bot_n4_1', title: 'In-depth notes: Ribosomes, Plastids & Cell Wall notes', fileUrl: 'https://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf', dateAdded: 'May 15, 2026' }
  ]
};

// Global default chapters/resources for items that mismatch above
export const DEFAULT_CHAPTERS: Chapter[] = [
  { id: 'def_ch1', name: 'Chapter 01 : Fundamentals & Concepts' },
  { id: 'def_ch2', name: 'Chapter 02 : Formulas & Core Systems' },
  { id: 'def_ch3', name: 'Chapter 03 : Intermediate Applications' },
  { id: 'def_ch4', name: 'Chapter 04 : Advanced Theory & Solving Session' }
];

export const DEFAULT_LECTURES: Lecture[] = [
  { _id: 'def_l1', title: 'L-01: Course Overview & Basic Standard Introduction', duration: '1h 10m', youtubeId: '2UjZ1IovB1A', dateAdded: 'May 28, 2026', thumbnailUrl: 'https://img.youtube.com/vi/2UjZ1IovB1A/0.jpg' },
  { _id: 'def_l2', title: 'L-02: Master Theory session with Practical Numerical Problems', duration: '1h 25m', youtubeId: 'tK3MTo7f_H4', dateAdded: 'May 28, 2026', thumbnailUrl: 'https://img.youtube.com/vi/tK3MTo7f_H4/0.jpg' }
];

export const DEFAULT_NOTES: Note[] = [
  { _id: 'def_n1', title: 'Official Revision Short Notes - Conceptual Summary pdf', fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', dateAdded: 'May 28, 2026' }
];
