import React from 'react';
import { Lecture } from '../types';
import { X, PlayCircle, Clock, Calendar, Film } from 'lucide-react';

interface VideoPlayerProps {
  lecture: Lecture;
  onClose: () => void;
}

export default function VideoPlayer({ lecture, onClose }: VideoPlayerProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-4xl overflow-hidden rounded-2xl bg-slate-950 shadow-2xl animate-slide-up border border-slate-800">
        {/* Top title navigation bar */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900 px-4 py-3 text-slate-200">
          <div className="flex items-center gap-2">
            <Film className="h-4 w-4 text-indigo-400" />
            <span className="font-display font-semibold text-xs sm:text-sm tracking-tight truncate max-w-[250px] sm:max-w-md">
              {lecture.title}
            </span>
          </div>
          <button 
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Video stream content container */}
        <div className="relative aspect-video w-full bg-black">
          {lecture.youtubeId ? (
            <iframe
              className="h-full w-full"
              src={`https://www.youtube.com/embed/${lecture.youtubeId}?autoplay=1&modestbranding=1&rel=0`}
              title={lecture.title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          ) : lecture.videoUrl || lecture.hlsUrl ? (
            <video
              className="h-full w-full"
              src={lecture.videoUrl || lecture.hlsUrl}
              controls
              autoPlay
              playsInline
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center p-6 text-center text-slate-500">
              <PlayCircle className="h-16 w-16 text-indigo-500/20 mb-3" />
              <p className="text-sm font-semibold text-slate-400">Lecture video stream not found</p>
              <p className="text-2xs text-slate-600 mt-1">This source is restricted or offline</p>
            </div>
          )}
        </div>

        {/* Details section footer */}
        <div className="bg-slate-900 p-4 sm:p-5 text-slate-300">
          <h3 className="font-display font-bold text-slate-100 text-sm sm:text-base leading-snug">
            {lecture.title}
          </h3>
          <div className="mt-2.5 flex flex-wrap items-center gap-4 text-xs text-slate-400">
            {lecture.duration && (
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-slate-500" />
                Duration: {lecture.duration}
              </span>
            )}
            {lecture.dateAdded && (
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5 text-slate-500" />
                Uploaded: {lecture.dateAdded}
              </span>
            )}
            <span className="flex items-center gap-1 font-mono text-[10px] text-indigo-400 font-semibold bg-indigo-950/40 border border-indigo-900/20 px-2 py-0.5 rounded-md">
              ⚡ COMPATIBLE PLAYER
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
