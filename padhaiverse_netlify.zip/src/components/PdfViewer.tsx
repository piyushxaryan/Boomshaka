import React from 'react';
import { Note } from '../types';
import { X, FileText, Download, ExternalLink, ShieldCheck } from 'lucide-react';

interface PdfViewerProps {
  note: Note;
  onClose: () => void;
}

export default function PdfViewer({ note, onClose }: PdfViewerProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-5xl h-[85vh] flex flex-col overflow-hidden rounded-2xl bg-white shadow-2xl animate-slide-up border border-slate-200">
        {/* Navigation title bar */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-3 text-slate-800">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-indigo-600" />
            <span className="font-display font-bold text-xs sm:text-sm tracking-tight truncate max-w-[250px] sm:max-w-xl">
              {note.title}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {/* Quick download button */}
            <a 
              href={note.fileUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex h-7 px-2.5 items-center gap-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-xs text-slate-600 hover:text-slate-900 transition-colors"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span className="hidden sm:inline font-semibold">Open Tab</span>
            </a>
            <button 
              onClick={onClose}
              className="flex h-7 w-7 items-center justify-center rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* PDF document workspace body */}
        <div className="flex-1 w-full bg-slate-100 relative">
          <iframe
            className="h-full w-full border-0"
            src={`https://docs.google.com/gview?url=${encodeURIComponent(note.fileUrl)}&embedded=true`}
            title={note.title}
          />
          {/* Quick instructions indicator overlay */}
          <div className="absolute right-4 bottom-4 bg-white/95 backdrop-blur-sm border border-slate-200 shadow-lg py-2 px-3.5 rounded-xl max-w-xs text-left">
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              <p className="text-2xs font-extrabold text-slate-800 uppercase tracking-widest leading-none">PadhaiVerse Secure Reader</p>
            </div>
            <p className="text-[10px] text-slate-500 leading-normal">
              If document fails to render inside this view, click <a href={note.fileUrl} target="_blank" rel="noopener noreferrer" className="text-indigo-600 font-bold hover:underline">Open Tab</a> to access it directly!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
