import React, { useState, useEffect } from 'react';
import { BookOpen, Clock, RefreshCw, Trophy } from 'lucide-react';

interface HeaderProps {
  onBackToDashboard?: () => void;
  isDashboard: boolean;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export default function Header({ onBackToDashboard, isDashboard, onRefresh, isRefreshing }: HeaderProps) {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-100 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl h-16 items-center justify-between px-4 sm:px-6">
        {/* Logo and Brand */}
        <div 
          className="flex items-center gap-2.5 cursor-pointer group"
          onClick={onBackToDashboard}
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white transition-transform group-hover:scale-105 shadow-md shadow-indigo-100">
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-display font-extrabold text-xl tracking-tight text-slate-900 flex items-center gap-1.5 leading-none">
              Padhai<span className="text-indigo-600">Verse</span>
            </h1>
            <p className="text-[10px] font-medium tracking-wider uppercase text-slate-400">Pure Study Space</p>
          </div>
        </div>

        {/* Info & Action Controls */}
        <div className="flex items-center gap-3">
          {/* Study Clock */}
          <div className="hidden sm:flex items-center gap-2 rounded-lg bg-slate-50 border border-slate-100 px-3 py-1.5 text-xs text-slate-500 font-mono">
            <Clock className="h-3.5 w-3.5 text-slate-400" />
            <span>{timeStr || '00:00:00'}</span>
          </div>

          {/* Quick Refresh if on main dashboard */}
          {isDashboard && onRefresh && (
            <button
              onClick={onRefresh}
              disabled={isRefreshing}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-all active:scale-95 disabled:opacity-50"
              title="Refresh Batches"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin text-indigo-600' : ''}`} />
            </button>
          )}

          {/* Dashboard Back Action button */}
          {!isDashboard && onBackToDashboard && (
            <button
              onClick={onBackToDashboard}
              className="rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors shadow-sm"
            >
              Dashboard
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
