import React, { useState } from 'react';
import { Announcement } from '../types';
import { Calendar, ChevronDown, ChevronUp, MessageSquare, Bell } from 'lucide-react';

interface NoticeCardProps {
  key?: string | number;
  announcement: Announcement;
}

export default function NoticeCard({ announcement }: NoticeCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return dateStr;
    }
  };

  const cleanText = (txt: string) => {
    // Basic formatting lines or links
    return txt.split('\n').map((line, i) => (
      <p key={i} className="mb-2 text-slate-600 last:mb-0 leading-relaxed text-xs sm:text-sm">
        {line}
      </p>
    ));
  };

  const isLong = announcement.announcement.length > 250;

  return (
    <div className="relative pl-6 pb-6 last:pb-2 border-l border-indigo-100 group">
      {/* Circle dot on timeline border */}
      <div className="absolute -left-1.5 top-1.5 flex h-3 w-3 items-center justify-center rounded-full bg-indigo-100 ring-4 ring-white group-hover:bg-indigo-600 group-hover:ring-indigo-150 transition-all" />

      {/* Actual content bubble */}
      <div className="rounded-2xl border border-slate-100 bg-white p-4 sm:p-5 shadow-sm hover:border-slate-200 transition-all">
        {/* Card heading info bar */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-50 pb-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
              <Bell className="h-4 w-4" />
            </div>
            <h4 className="font-display font-bold text-slate-800 leading-snug tracking-tight text-sm">
              {announcement.heading || 'Notice Update'}
            </h4>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] font-semibold text-slate-400 font-mono">
            <Calendar className="h-3 w-3 text-slate-300" />
            <span>{formatDate(announcement.createdAt)}</span>
          </div>
        </div>

        {/* Text body */}
        <div className="text-slate-600 break-words font-sans">
          {isLong && !isExpanded ? (
            <div>
              {cleanText(announcement.announcement.slice(0, 250) + '...')}
              <button 
                onClick={() => setIsExpanded(true)}
                className="mt-2.5 inline-flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800"
              >
                Read Full Announcement
                <ChevronDown className="h-3 w-3" />
              </button>
            </div>
          ) : (
            <div>
              {cleanText(announcement.announcement)}
              {isLong && (
                <button 
                  onClick={() => setIsExpanded(false)}
                  className="mt-2.5 inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-slate-800"
                >
                  Collapse Notice
                  <ChevronUp className="h-3 w-3" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
