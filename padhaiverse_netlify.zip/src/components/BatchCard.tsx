import React from 'react';
import { Batch } from '../types';
import { Layers, Play, Award, Zap } from 'lucide-react';

interface BatchCardProps {
  key?: string | number;
  batch: Batch;
  onOpen: (batch: Batch) => void;
}

export default function BatchCard({ batch, onOpen }: BatchCardProps) {
  // Extract category for cleaner visual tag labels
  const getBatchTag = (name: string) => {
    const uppercaseName = name.toUpperCase();
    if (uppercaseName.includes('JEE')) return { label: 'IIT-JEE', bg: 'bg-blue-50 text-blue-700 border-blue-100' };
    if (uppercaseName.includes('NEET')) return { label: 'NEET', bg: 'bg-emerald-50 text-emerald-700 border-emerald-100' };
    if (uppercaseName.includes('CLASS-12') || uppercaseName.includes('12TH')) return { label: 'Class 12', bg: 'bg-purple-50 text-purple-700 border-purple-100' };
    if (uppercaseName.includes('CLASS-11') || uppercaseName.includes('11TH')) return { label: 'Class 11', bg: 'bg-amber-50 text-amber-700 border-amber-100' };
    if (uppercaseName.includes('CLASS-10') || uppercaseName.includes('10TH') || uppercaseName.includes('BOARD')) return { label: 'Boards', bg: 'bg-rose-50 text-rose-700 border-rose-100' };
    return { label: 'Foundation', bg: 'bg-slate-50 text-slate-700 border-slate-100' };
  };

  const tag = getBatchTag(batch.batch_name);

  return (
    <div 
      className="group flex flex-col overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm transition-all duration-300 hover:border-slate-200 hover:shadow-md hover:-translate-y-1 cursor-pointer"
      onClick={() => onOpen(batch)}
    >
      {/* Thumbnail Aspect Container */}
      <div className="relative aspect-video w-full overflow-hidden bg-slate-100 select-none">
        {batch.batch_image_url ? (
          <img 
            src={batch.batch_image_url} 
            alt={batch.batch_name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-102"
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Fail-safe fallbacks for images
              (e.target as HTMLImageElement).src = "https://static.pw.live/5eb393ee95fab7468a79d189/ADMIN/ec947628-7b9d-4c30-bbc4-c0c3e3db78a2.jpeg";
            }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-indigo-50">
            <Layers className="h-10 w-10 text-indigo-200" />
          </div>
        )}

        {/* Status indicator pill top right */}
        {batch.batch_status && (
          <span className={`absolute top-3 right-3 flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold tracking-wider uppercase text-white shadow-sm ${
            batch.batch_status === 'new' ? 'bg-indigo-600' : 'bg-slate-800'
          }`}>
            <Zap className="h-2.5 w-2.5" />
            {batch.batch_status}
          </span>
        )}
      </div>

      {/* Frame body */}
      <div className="flex flex-1 flex-col p-4">
        {/* Row 1 Tag identifier */}
        <div className="mb-2">
          <span className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[10px] font-semibold ${tag.bg}`}>
            {tag.label}
          </span>
        </div>

        {/* Row 2 Title */}
        <h3 className="font-display font-bold text-slate-800 leading-tight tracking-tight text-sm line-clamp-2 min-h-[40px] group-hover:text-indigo-600 transition-colors">
          {batch.batch_name}
        </h3>

        {/* Row 3 CTA launch bottom */}
        <div className="mt-4 flex items-center justify-between border-t border-slate-50 pt-3">
          <div className="flex items-center gap-1 text-[11px] font-medium text-slate-400">
            <span className="font-mono text-[10px] text-slate-300">ID:</span>
            <span className="font-mono text-[9px] font-semibold tracking-wider truncate max-w-[80px]">{batch.batch_id}</span>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:translate-x-0.5 transition-transform">
            Start Learning
            <Play className="h-3 w-3 fill-indigo-600 text-indigo-600" />
          </span>
        </div>
      </div>
    </div>
  );
}
