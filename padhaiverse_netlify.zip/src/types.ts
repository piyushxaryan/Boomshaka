export interface Batch {
  batch_id: string;
  batch_name: string;
  batch_image_url: string;
  batch_status: string;
}

export interface Subject {
  id: string;
  name: string;
  description?: string;
  imageUrl?: string;
  teachers?: string[];
}

export interface Chapter {
  id: string;
  name: string;
  chapterUrl?: string;
}

export interface Lecture {
  _id: string;
  title: string;
  duration?: string;
  videoUrl?: string;
  hlsUrl?: string;
  youtubeId?: string;
  dateAdded?: string;
  thumbnailUrl?: string;
  sequenceNo?: number;
}

export interface Note {
  _id: string;
  title: string;
  fileUrl: string;
  tag?: string;
  dateAdded?: string;
}

export interface Announcement {
  _id: string;
  heading: string;
  announcement: string;
  createdAt: string;
  type?: string;
}
